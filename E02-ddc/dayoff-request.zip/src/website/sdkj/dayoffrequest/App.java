package website.sdkj.dayoffrequest;

import java.io.PrintWriter;
import java.util.Scanner;

import website.sdkj.dayoffrequest.boundary.WorkerCalendarUI;
import website.sdkj.dayoffrequest.controler.DayOffControler;
import website.sdkj.dayoffrequest.dao.DayOffDao;
import website.sdkj.dayoffrequest.entity.Role;

public class App {

	public static void main(String[] args) throws ClassNotFoundException {
		Scanner reader = new Scanner(System.in);
		System.out.print("workerId: ");
		int workerId = 1; //reader.nextInt();
		Role role = getRoleFromArgs(args);
		DayOffDao dao = new DayOffDao("org.mariadb.jdbc.Driver", "jdbc:mariadb://localhost", "dayoff", "root", "root");
		DayOffControler controler = new DayOffControler(dao);
		WorkerCalendarUI workerCalendarUI = new WorkerCalendarUI(workerId, controler, reader, new PrintWriter(System.out));
		workerCalendarUI.run();
		System.out.println("bye-bye");
	}

	public static Role getRoleFromArgs(String[] args) {
		Role role = new Role(false, false, false);
		for(String arg : args) {
			switch (arg.toLowerCase()) {
				case "worker":
					role.setWorker(true);
					break;
				case "manager":
					role.setManager(true);
					break;
				case "rh":
					role.setRH(true);
					break;
				case "help":
				case "/h":
				case "/help":
				case "-help":
				case "--help":
					showHelp();
					break;
				default:
					System.err.println("Argument inconnu " + arg);
			}
		}
		return role;
	}

	private static void showHelp() {
		System.out.println("aide");
		System.out.println("java -jar dayoffrequest worker manager rh");
		System.out.println("java -jar help");
	}

}
