package website.sdkj.dayoffrequest.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import website.sdkj.dayoffrequest.entity.DayOff;
import website.sdkj.dayoffrequest.entity.DayOffStatus;

public class DayOffDao {
	private final String uri;
	private final String database;
	private final String user;
	private final String password;

	public DayOffDao(String driver, String uri, String database, String user, String password) throws ClassNotFoundException {
		super();
		Class.forName(driver);
		this.uri = uri;
		this.database = database;
		this.user = user;
		this.password = password;
	}

	private Connection getConnection() throws SQLException {
		return DriverManager.getConnection(uri + "/" + database, user, password);
	}

	private java.sql.Date javaToSqlDate(java.util.Date javaDate) {
		return new java.sql.Date(javaDate.getTime());
	}

	private java.util.Date sqlToJavaDate(java.sql.Date sqlDate) {
		return new java.util.Date(sqlDate.getTime());
	}

	public void create(DayOff dayOff) throws SQLException {
		try (Connection con = getConnection()) {
			String sql = "INSERT INTO day_off VALUES (start, end, status) VALUES (?, ?, ?)";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setDate(1, javaToSqlDate(dayOff.getStart()));
			ps.setDate(2, javaToSqlDate(dayOff.getEnd()));
			ps.setString(3, dayOff.getStatus().toString());
			int nrInsert = ps.executeUpdate();
			if (nrInsert != 1) throw new SQLException(
					"insert day_off returned " + nrInsert + " record\n" +
					"request " + sql + "\n" +
					"dayOff" + dayOff.toString()
					);
		}
	}

	public void update(DayOff dayOff) throws SQLException {
		try (Connection con = getConnection()) {
			String sql = "UPDATE day_off SET start=?, end=?, status=? WHERE id=?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setDate(1, javaToSqlDate(dayOff.getStart()));
			ps.setDate(2, javaToSqlDate(dayOff.getEnd()));
			ps.setString(3, dayOff.getStatus().toString());
			ps.setInt(4, dayOff.getId());
			int nrUpdate = ps.executeUpdate();
			if (nrUpdate != 1) throw new SQLException(
					"insert dayoff returned " + nrUpdate + " record\n" +
					"request " + sql + "\n" +
					"dayOff" + dayOff.toString()
					);
		}
	}

	public List<DayOff> fetchDayOff() throws SQLException {
		try (Connection con = getConnection()) {
			List<DayOff> dayOffs = new ArrayList<DayOff>();
			String sql = "SELECT d.id AS id, d.start AS start, d.end AS end, c.name AS category, s.name AS status FROM day_off d INNER JOIN day_off_category c ON d.day_off_category_id = c.id INNER JOIN day_off_status s ON d.day_off_status_id = s.id";
			//String sql = "SELECT * FROM day_off";
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(sql);
			while (rs.next()) {
				int id = rs.getInt("id");
				java.util.Date start = javaToSqlDate(rs.getDate("start"));
				java.util.Date end = javaToSqlDate(rs.getDate("end"));
				DayOffStatus status = DayOffStatus.valueOf(rs.getString("status"));
				dayOffs.add(new DayOff(id, start, end, status));
			}
			return dayOffs;
		}
	}

	public DayOff getDayOff(int id) throws SQLException {
		try (Connection con = getConnection()) {
			String sql = "SELECT * FROM day_off WHERE id=?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery(sql);
			if (rs.next()) {
				java.util.Date start = javaToSqlDate(rs.getDate("start"));
				java.util.Date end = javaToSqlDate(rs.getDate("end"));
				DayOffStatus status = DayOffStatus.valueOf(rs.getString("status"));
				DayOff dayOff = new DayOff(id, start, end, status);
				if (rs.next()) throw new SQLException("more than one dayoff for id " + id);
				else return dayOff;
			}
			throw new SQLException("no dayoff with id " + id);
		}
	}

	public List<DayOff> fetchDayOffByWorker(int workerId) throws SQLException {
		// TODO where
		return fetchDayOff();
	}

	public List<DayOff> fetchDayOffByManager(int managerId) throws SQLException {
		// TODO where
		return fetchDayOff();
	}
}
