package website.sdkj.dayoffrequest.boundary;

import java.io.PrintWriter;
import java.util.List;
import java.util.Scanner;

import website.sdkj.dayoffrequest.AppException;
import website.sdkj.dayoffrequest.controler.DayOffControler;
import website.sdkj.dayoffrequest.entity.DayOff;

public class WorkerCalendarUI {
	private int workerId;
	private DayOffControler controller;
	private Scanner scanner;
	private PrintWriter writer;

	public WorkerCalendarUI(int workerId, DayOffControler controller, Scanner scanner, PrintWriter writer) {
		super();
		this.workerId = workerId;
		this.controller = controller;
		this.scanner = scanner;
		this.writer = writer;
	}

	public void run() {
		writer.println("\n-------------------------------\n");
		writer.println("--------------------------------");
		writer.println("--- liste des congés ---");
		writer.println("--------------------------------");
		try {
			List<DayOff> dayOffs = controller.fetchDayOffByWorker(workerId);
			for (DayOff d : dayOffs) {
				writer.println(d.getId() + " " + d.getStart() + " - " + d.getEnd() + " - " + d.getStatus().toString());
				writer.flush();
			}
		} catch (AppException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
