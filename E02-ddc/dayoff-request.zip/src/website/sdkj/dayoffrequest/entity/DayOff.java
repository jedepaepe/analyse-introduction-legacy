package website.sdkj.dayoffrequest.entity;

import java.util.Date;

import website.sdkj.dayoffrequest.AppException;

public class DayOff {
	private int id;
	private Date start;
	private Date end;
	private DayOffStatus status;

	public DayOff(int id, Date start, Date end, DayOffStatus status) {
		super();
		this.id = id;
		this.start = start;
		this.end = end;
		this.status = status;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Date getStart() {
		return start;
	}
	public void setStart(Date start) {
		this.start = start;
	}
	public Date getEnd() {
		return end;
	}
	public void setEnd(Date end) {
		this.end = end;
	}
	public DayOffStatus getStatus() {
		return status;
	}
	public void setStatus(DayOffStatus status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "DayOff [start=" + start + ", end=" + end + ", status=" + status + "]";
	}

	public void cancel() throws AppException {
		if (status == DayOffStatus.CONSUMED) {
			throw new AppException(id + ":DayOff in state CONSUMED is not allowed to change to " + DayOffStatus.CANCELLED.toString());
		}
		status = DayOffStatus.CANCELLED;
	}

	public void approveManager(boolean approved) throws AppException {
		DayOffStatus newStatus = approved ? DayOffStatus.APPROVED_MANAGER : DayOffStatus.REJECTED_MANAGER;
		if (status != DayOffStatus.REQUEST) {
			throw new AppException(id + ":DayOff in state " + status + " is not allowed to change to " + newStatus.toString());
		}

	}

	public void approveRH(boolean approved) throws AppException {
		DayOffStatus newStatus = approved ? DayOffStatus.APPROVED_RH : DayOffStatus.REJECTED_MANAGER;
		if (status != DayOffStatus.APPROVED_MANAGER) {
			throw new AppException(id + ":DayOff in state " + status + " is not allowed to change to " + newStatus.toString());
		}
		status = newStatus;
	}
}
