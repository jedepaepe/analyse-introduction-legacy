package website.sdkj.dayoffrequest.entity;

import java.util.List;

public class Manager extends Worker {
	private List<Worker> workers;

	public List<Worker> getWorkers() {
		return workers;
	}

	public void setWorkers(List<Worker> workers) {
		this.workers = workers;
	}
}
