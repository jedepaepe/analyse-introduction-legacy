package website.sdkj.dayoffrequest.entity;

public class Role {
	private boolean isWorker;
	private boolean isManager;
	private boolean isRH;

	public Role() {
		super();
	}

	public Role(boolean isWorker, boolean isManager, boolean isRH) {
		super();
		this.isWorker = isWorker;
		this.isManager = isManager;
		this.isRH = isRH;
	}

	public boolean isWorker() {
		return isWorker;
	}

	public void setWorker(boolean isWorker) {
		this.isWorker = isWorker;
	}

	public boolean isManager() {
		return isManager;
	}

	public void setManager(boolean isManager) {
		this.isManager = isManager;
	}

	public boolean isRH() {
		return isRH;
	}

	public void setRH(boolean isRH) {
		this.isRH = isRH;
	}
}
