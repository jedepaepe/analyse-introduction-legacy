package website.sdkj.dayoffrequest.entity;

public enum DayOffStatus {
	REQUEST,
	APPROVED_MANAGER,
	APPROVED_RH,
	CONSUMED,
	CANCELLED,
	REJECTED_MANAGER,
	REJECTED_RH
}
