package website.sdkj.dayoffrequest;

public class AppException extends Exception {
	public AppException() {}
	public AppException(String msg) {
		super(msg);
	}
}
