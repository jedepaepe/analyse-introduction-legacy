package website.sdkj.dayoffrequest.controler;

import java.sql.SQLException;
import java.util.List;

import website.sdkj.dayoffrequest.AppException;
import website.sdkj.dayoffrequest.dao.DayOffDao;
import website.sdkj.dayoffrequest.entity.DayOff;

public class DayOffControler {
	private final DayOffDao dao;

	public DayOffControler(DayOffDao dao) {
		super();
		this.dao = dao;
	}

	public void requestDayOff(DayOff dayOff) throws AppException {
		try {
			dao.create(dayOff);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new AppException();
		}
	}

	public void cancelDayOff(int dayOffId) throws AppException {
		try {
			DayOff dayOff = dao.getDayOff(dayOffId);
			dayOff.cancel();
			dao.update(dayOff);
		} catch(SQLException e) {
			e.printStackTrace();
			throw new AppException();
		}
	}

	public void approveDayOffManager(int dayOffId, boolean approved) throws AppException {
		try {
			DayOff dayOff = dao.getDayOff(dayOffId);
			dayOff.approveManager(approved);
			dao.update(dayOff);
		} catch(SQLException e) {
			e.printStackTrace();
			throw new AppException();
		}
	}

	public void approveDayOffRH(int dayOffId, boolean approved) throws AppException {
		try {
			DayOff dayOff = dao.getDayOff(dayOffId);
			dayOff.approveRH(approved);
			dao.update(dayOff);
		} catch(SQLException e) {
			e.printStackTrace();
			throw new AppException();
		}
	}

	public List<DayOff> fetchDayOffByWorker(int workerId) throws AppException {
		try {
			return dao.fetchDayOffByWorker(workerId);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new AppException();
		}
	}
}
